package avenger.weather.weatherRequested;


public class TestLocation {

	
	public static void main(String[] args) {
		
		Location location=new Location("Cork");
		System.out.println("City: "+location.getCity());
		System.out.println("Country: "+location.getCountry());
	}
	

}
